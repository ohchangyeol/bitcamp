import java.util.Vector;

public class StringUtil{
	

	private static String replaceString(String[] arr){
		int count=0;
		int temp=0;
		String result="";
		for (int i = 0 ; i < arr.length; i++){
			for(int j =0 ; j < arr[i].length();j++ ){// ī���� ����.
				if (arr[i].charAt(j)=='a'){
					count++;
				}
			}// �ϳ��� ������ ���� a�� ��
			if (temp < count){ 
				temp = count;
				result = arr[i];
				count = 0;
			}
		}
		System.out.println(result);
		return result.replace('a', 'A');
	}
	public static void main(String[] agrs){
		
		String[] arr = {"java program","array","java program area","append"};
		String resuit = StringUtil.replaceString(arr);
		System.out.println("����� ���ڿ� " + resuit);
	}//end of main

}//end of class 